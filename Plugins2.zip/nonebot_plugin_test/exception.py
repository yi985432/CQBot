#!/usr/bin/env python3
# -*- coding: utf-8 -*-


class UnAuthorized(Exception):
    pass


class UnknowAdapter(Exception):
    pass


class BadRequest(Exception):
    pass
